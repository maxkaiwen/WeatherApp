package example.com.weatherapp.ui.main.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import example.com.weatherapp.data.repository.MainRepository
import example.com.weatherapp.utils.Resource

import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.schedulers.Schedulers
class MainViewModel(private val mainRepository: MainRepository) : ViewModel() {

    private val cities=MutableLiveData<Resource<List<City>>>()
    private val compositeDisposable=CompositeDisposable()

    init{
        fetchCities()

    }

    private fun fetchCities() {
        cities.postValue(Resource.loading(null))
        compositeDisposable.add(
            mainRepository.getCities()
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({cityList-> cities.postValue(
                    Resource.success(cityList)
                )},{throwable->
                    cities.postValue(Resource.error("Error fetchCities ", null))
                })

        )
    }
    override fun onCleared() {
        super.onCleared()
        compositeDisposable.dispose()
    }

    fun getCities(): LiveData<Resource<List<City>>> {
        return cities
    }

}