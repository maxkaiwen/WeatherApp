package example.com.weatherapp.data.api
import example.com.weatherapp.data.model.JsonModel
import io.reactivex.Single
interface ApiService {
    fun getCities(): Single<List<JsonModel>>
}