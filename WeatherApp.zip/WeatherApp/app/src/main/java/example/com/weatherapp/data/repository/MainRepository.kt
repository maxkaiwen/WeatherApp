package example.com.weatherapp.data.repository

import example.com.weatherapp.data.api.ApiHelper
import io.reactivex.Single

class MainRepository(private val apiHelper: ApiHelper) {

    fun getCities(): Single<List<City>> {
        return apiHelper.getCities()
    }

}