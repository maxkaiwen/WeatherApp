package example.com.weatherapp.utils

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}